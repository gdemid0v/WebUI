#!/bin/sh

echo "Content-Type: application/json"
echo ""

read -r data

IP=$(echo "$data" | sed -n 's/.*"ip":"\([^"]*\)".*/\1/p')
MASK=$(echo "$data" | sed -n 's/.*"mask":"\([^"]*\)".*/\1/p')

if [ -z "$IP" ] || [ -z "$MASK" ]; then
    echo '{"status": "error", "message": "Invalid IP or mask"}' >&2
    exit 1
fi

CONFIG_DIR="/tmp"
NEW_FILE="interfaces_$(date +%s).conf"
FULL_PATH="${CONFIG_DIR}/${NEW_FILE}"

cat > "$FULL_PATH" <<EOF
# Configure Loopback
auto lo
iface lo inet loopback
#
auto eth0
iface eth0 inet static
 hwaddress ether 00:00:00:00:00:AA
 address $IP
 netmask $MASK
#gateway 192.168.1.1
EOF

if [ -f "$FULL_PATH" ]; then
    echo '{"status": "success", "filename": "'$NEW_FILE'"}'
else
    echo '{"status": "error", "message": "File creation failed"}' >&2
    exit 1
fi