#!/bin/sh

echo "Content-Type: application/json; charset=utf-8"
echo ""

MANUFACTURER="РЭА-Т"
MODEL="КРОНОС SI-SDB2-MB-2U"

# Получение интерфейса
INTERFACE="eth0"

IP_OUTPUT=$(ip -4 addr show "$INTERFACE")
IP_ADDRESS=$(echo "$IP_OUTPUT" | grep -o 'inet [0-9.]*' | awk '{print $2}')
NETMASK=$(echo "$IP_OUTPUT" | grep -o 'inet [0-9./]*' | cut -d'/' -f2)

# Текущая дата
TIME=$(date "+%H:%M:%S %d.%m.%Y")

# Время работы системы (Значение в секундах)
UPTIME=$(awk '{printf $1}' /proc/uptime)

# Возврат в JSON
cat <<EOF
{
  "Manufacturer": "$MANUFACTURER",
  "Model": "$MODEL",
  "IP-Address": "$IP_ADDRESS",
  "Netmask": "$NETMASK",
  "UPtime": "$UPTIME",
  "Time": "$TIME"
}
EOF